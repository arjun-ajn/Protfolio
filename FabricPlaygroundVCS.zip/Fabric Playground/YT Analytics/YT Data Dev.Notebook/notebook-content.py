# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "ef13f88d-d179-4002-acb4-91ec1a61690c",
# META       "default_lakehouse_name": "Learning_Lakehouse",
# META       "default_lakehouse_workspace_id": "bc05e361-9f49-4f28-ae66-87d8e1968bd9",
# META       "known_lakehouses": [
# META         {
# META           "id": "ef13f88d-d179-4002-acb4-91ec1a61690c"
# META         }
# META       ]
# META     },
# META     "environment": {
# META       "environmentId": "57f9b112-9748-aa7c-4d32-13d818108dcd",
# META       "workspaceId": "00000000-0000-0000-0000-000000000000"
# META     }
# META   }
# META }

# CELL ********************

# Welcome to your new notebook
# Type here in the cell editor to add code!


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Install Google API Client libraries (if not already available)
!pip install --upgrade google-auth google-auth-oauthlib google-api-python-client

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Authentication file
client_secrets_path = '/lakehouse/default/Files/YTPowerBi/client_secret.json'

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

import pandas as pd
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build

# OAuth 2.0 scope
SCOPES = ['https://www.googleapis.com/auth/yt-analytics.readonly']

# Authenticate
# flow = InstalledAppFlow.from_client_secrets_file('client_secret.json', SCOPES)
flow = InstalledAppFlow.from_client_secrets_file(client_secrets_path, SCOPES)
credentials = flow.run_local_server(port=0)

# Build the YouTube Analytics API client
youtube_analytics = build('youtubeAnalytics', 'v2', credentials=credentials)


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************


# Example query: Get views per day
request = youtube_analytics.reports().query(
    ids='channel==UC7YCV4bGHBh50anJ16zOkQQ',
    startDate='2024-04-01',
    endDate='2024-04-25',
    metrics='views,watchTimeMinutes',
    dimensions='day',
    sort='day'
)
response = request.execute()

# Convert to DataFrame
df = pd.DataFrame(response['rows'], columns=[col['name'] for col in response['columnHeaders']])
display(df)


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# BELOW CODE TO TEST Oauth to fetch more analytics data from youtube

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Install google auth and YouTube libraries
# Not required if added to environment - already added hence commenting out
# !pip install google-auth google-auth-oauthlib google-auth-httplib2 google-api-python-client


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build
import pandas as pd
from datetime import datetime

import os
import pickle
from google.auth.transport.requests import Request  #For oAuth Token reauthentication testing

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Path to your client_secrets.json
CLIENT_SECRET_FILE = '/lakehouse/default/Files/YTPowerBi/client_secret_desktop.json'
TOKEN_FILE = '/lakehouse/default/Files/token.pickle'  # Pickle format preferred in notebooks

# Scopes for YouTube Data + Analytics
SCOPES = [
    'https://www.googleapis.com/auth/yt-analytics.readonly',
    'https://www.googleapis.com/auth/youtube.readonly'
]

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Test reauthentication automation
# Load or create credentials
def get_authenticated_service():
    creds = None

    # Try to load existing credentials
    if os.path.exists(TOKEN_FILE):
        with open(TOKEN_FILE, 'rb') as token:
            creds = pickle.load(token)

    # If not valid, run auth flow
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file(CLIENT_SECRET_FILE, SCOPES)

            # auth_url, _ = flow.authorization_url(prompt='consent')
            auth_url, _ = flow.authorization_url(prompt='consent', access_type='offline', include_granted_scopes='true')

            print(f"Please go to this URL to authorize:\n{auth_url}")
            code = input("Enter the authorization code: ")
            flow.fetch_token(code=code)
            creds = flow.credentials

        # Save credentials
        with open(TOKEN_FILE, 'wb') as token:
            pickle.dump(creds, token)

    return build('youtube', 'v3', credentials=creds)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Test the reauthentication function
youtube = get_authenticated_service()

# If this works, replace the code "youtube = build('youtube', 'v3', credentials=credentials)" in the 2nd follwoing cell

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Authenticate user
flow = InstalledAppFlow.from_client_secrets_file(CLIENT_SECRET_FILE, SCOPES)
# credentials = flow.run_local_server(port=0)

# below code as this is not from a local browser, but server 
auth_url, _ = flow.authorization_url(prompt='consent')
print(f"Please go to this URL: {auth_url}")

# After user visits the URL, they will get a code.
code = input("Enter the authorization code here: ")
flow.fetch_token(code=code)


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Create API service clients
youtube = build('youtube', 'v3', credentials=credentials)
youtube_analytics = build('youtubeAnalytics', 'v2', credentials=credentials)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Get Video Insights (including Shorts) for Owned Channel
def get_video_and_shorts_insights():
    now = datetime.utcnow().strftime('%Y-%m-%d')
    thirty_days_ago = (datetime.utcnow() - pd.Timedelta(days=30)).strftime('%Y-%m-%d')
    
    response = youtube_analytics.reports().query(
        ids='channel==MINE',
        startDate=thirty_days_ago,
        endDate=now,
        metrics='views,likes,comments,estimatedMinutesWatched,averageViewDuration',
        dimensions='video',
        filters='isShort==1',  # <- Filter for Shorts Only
        sort='-views'
    ).execute()

    # Parse into DataFrame
    rows = response.get('rows', [])
    columns = [header['name'] for header in response['columnHeaders']]
    df_shorts = pd.DataFrame(rows, columns=columns)

    return df_shorts


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def get_regular_video_insights():
    now = datetime.utcnow().strftime('%Y-%m-%d')
    thirty_days_ago = (datetime.utcnow() - pd.Timedelta(days=30)).strftime('%Y-%m-%d')
    
    response = youtube_analytics.reports().query(
        ids='channel==MINE',
        startDate=thirty_days_ago,
        endDate=now,
        metrics='views,likes,comments,estimatedMinutesWatched,averageViewDuration',
        dimensions='video',
        filters='isShort==0',  # <- Filter for regular videos
        sort='-views'
    ).execute()

    rows = response.get('rows', [])
    columns = [header['name'] for header in response['columnHeaders']]
    df_videos = pd.DataFrame(rows, columns=columns)

    return df_videos


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Fetch Data
df_shorts = get_video_and_shorts_insights()
df_videos = get_regular_video_insights()

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# TEST NO AUTHENTICATION DATA RETRIEVAL

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

import pandas as pd
from googleapiclient.discovery import build
from google.oauth2.credentials import Credentials
from datetime import datetime, timedelta
import os
import pickle


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************


# Configuration - replace these with your values
CHANNEL_ID = "YOUR_CHANNEL_ID"  # Find in YouTube Studio -> Settings -> Advanced
CLIENT_SECRETS = {
    "installed":{
    "client_id":"178790580678-81a9ki66b6q8ff92rn9pgoncshgu8pcc.apps.googleusercontent.com",
    "project_id":"shaped-complex-315416",
    "auth_uri":"https://accounts.google.com/o/oauth2/auth",
    "token_uri":"https://oauth2.googleapis.com/token",
    "auth_provider_x509_cert_url":"https://www.googleapis.com/oauth2/v1/certs",
    "client_secret":"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",
    "redirect_uris":["http://localhost"]
    }
}
'''
CLIENT_SECRETS = {
    "installed": {
        "client_id": "178790580678-81a9ki66b6q8ff92rn9pgoncshgu8pcc.apps.googleusercontent.com",
        "client_secret": "YOUR_CLIENT_SECRET",
        "project_id": "shaped-complex-315416",
        "auth_uri": "https://accounts.google.com/o/oauth2/auth",
        "token_uri": "https://oauth2.googleapis.com/token",
        "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
        "redirect_uris": ["http://localhost"]
    }
}
'''

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# One-time function to generate refresh token (run this separately)
def generate_refresh_token():
    from google_auth_oauthlib.flow import InstalledAppFlow
    flow = InstalledAppFlow.from_client_config(
        CLIENT_SECRETS,
        scopes=['https://www.googleapis.com/auth/yt-analytics.readonly',
                'https://www.googleapis.com/auth/youtube.readonly']
    )
    credentials = flow.run_local_server(port=0)
    with open('refresh_token.pickle', 'wb') as token:
        pickle.dump(credentials.refresh_token, token)
    return credentials.refresh_token


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Main function using refresh token
def get_authenticated_service():
    # Load refresh token if exists
    if os.path.exists('refresh_token.pickle'):
        with open('refresh_token.pickle', 'rb') as token:
            refresh_token = pickle.load(token)
    else:
        refresh_token = generate_refresh_token()
    
    credentials = Credentials(
        None,
        refresh_token=refresh_token,
        token_uri="https://oauth2.googleapis.com/token",
        client_id=CLIENT_SECRETS['installed']['client_id'],
        client_secret=CLIENT_SECRETS['installed']['client_secret']
    )
    
    youtube_analytics = build('youtubeAnalytics', 'v2', credentials=credentials)
    youtube = build('youtube', 'v3', credentials=credentials)
    return youtube_analytics, youtube

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Execute
youtube_analytics, youtube = get_authenticated_service()
daily_metrics, video_metrics, content_summary = main()

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Output datasets for Power BI
daily_metrics
video_metrics
content_summary

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

from google.oauth2 import service_account
from googleapiclient.discovery import build

# Service account approach (limited to channels you own)
SERVICE_ACCOUNT_FILE = 'service_account.json'  # Download from Google Cloud Console
SCOPES = ['https://www.googleapis.com/auth/yt-analytics.readonly']

def get_service_account_service():
    credentials = service_account.Credentials.from_service_account_file(
        SERVICE_ACCOUNT_FILE, scopes=SCOPES)
    
    # Service accounts need delegation for YouTube
    credentials = credentials.with_subject('OWNER_EMAIL@DOMAIN.COM')  # Must be owner of channel
    
    youtube_analytics = build('youtubeAnalytics', 'v2', credentials=credentials)
    youtube = build('youtube', 'v3', credentials=credentials)
    return youtube_analytics, youtube

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# SERVICE ACCOUNT CODE

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Import required libraries
import pandas as pd
from googleapiclient.discovery import build
from google_auth_oauthlib.flow import InstalledAppFlow
from datetime import datetime, timedelta
import os
import json
from notebookutils import mssparkutils


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************


# Set up authentication
SCOPES = ['https://www.googleapis.com/auth/yt-analytics.readonly',
          'https://www.googleapis.com/auth/youtube.readonly']

# Path to your client secrets file in Lakehouse
client_secrets_path = '/lakehouse/default/Files/YTPowerBi/service_account.json'

# Function to read file from Lakehouse using File API
def read_lakehouse_file(file_path):
    try:
        # Using Fabric's file API
        with open(file_path, 'r') as f:
            return json.load(f)
    except Exception as e:
        raise FileNotFoundError(f"Failed to load client secrets from {file_path}: {str(e)}")
# Function to properly format client secrets
def get_client_config(file_path):
    try:
        with open(file_path, 'r') as f:
            client_secrets = json.load(f)
        
        # Ensure the client secrets are in the correct format
        if 'installed' in client_secrets:
            client_secrets['installed'] = client_secrets.pop('installed')
        if 'web' in client_secrets:
            raise ValueError("Web application credentials are not supported. Please use 'installed' app credentials.")
        
        if 'installed' not in client_secrets:
            raise ValueError("Client secrets must be for an installed app")
            
        return client_secrets
    except Exception as e:
        raise ValueError(f"Error loading client secrets: {str(e)}")
# Function to authenticate and get service
def get_authenticated_service():
    # Load client secrets from Lakehouse
    try:
        client_secrets = read_lakehouse_file(client_secrets_path)
    except Exception as e:
        raise FileNotFoundError(f"Failed to load client secrets: {e}")
    
    # Create flow from the loaded client secrets
    flow = InstalledAppFlow.from_client_config(
        client_secrets,
        scopes=SCOPES
    )
    
    # Run local server flow for authentication
    credentials = flow.run_local_server(port=0)
    
    # Build services
    youtube_analytics = build('youtubeAnalytics', 'v2', credentials=credentials)
    youtube = build('youtube', 'v3', credentials=credentials)
    
    return youtube_analytics, youtube

# Function to get channel ID
def get_channel_id(youtube_service):
    request = youtube_service.channels().list(
        part="id",
        mine=True
    )
    response = request.execute()
    return response['items'][0]['id']

# Function to fetch analytics data
def fetch_analytics_data(youtube_analytics, channel_id, start_date, end_date):
    # Get basic metrics
    metrics_request = youtube_analytics.reports().query(
        ids=f"channel=={channel_id}",
        startDate=start_date,
        endDate=end_date,
        metrics="views,estimatedMinutesWatched,likes,subscribersGained",
        dimensions="day",
        sort="day"
    )
    metrics_response = metrics_request.execute()
    
    # Get video-level data
    video_request = youtube_analytics.reports().query(
        ids=f"channel=={channel_id}",
        startDate=start_date,
        endDate=end_date,
        metrics="views,estimatedMinutesWatched,likes,comments",
        dimensions="video",
        sort="-views",
        maxResults=200
    )
    video_response = video_request.execute()
    
    return metrics_response, video_response

# Function to get video details
def get_video_details(youtube_service, video_ids):
    video_data = []
    for i in range(0, len(video_ids), 50):
        batch = video_ids[i:i+50]
        request = youtube_service.videos().list(
            part="contentDetails,snippet,statistics",
            id=",".join(batch)
        )
        response = request.execute()
        video_data.extend(response['items'])
    return video_data



# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Import required libraries
import pandas as pd
from googleapiclient.discovery import build
from google_auth_oauthlib.flow import InstalledAppFlow
from datetime import datetime, timedelta
import os
import json

# Set up authentication
SCOPES = ['https://www.googleapis.com/auth/yt-analytics.readonly',
          'https://www.googleapis.com/auth/youtube.readonly']

# Path to your client secrets file in Lakehouse
client_secrets_path = '/lakehouse/default/Files/YTPowerBi/client_secret.json'

# Function to properly format client secrets
def get_client_config(file_path):
    try:
        with open(file_path, 'r') as f:
            client_secrets = json.load(f)
        
        # Ensure the client secrets are in the correct format
        if 'installed' in client_secrets:
            client_secrets['installed'] = client_secrets.pop('installed')
        if 'web' in client_secrets:
            raise ValueError("Web application credentials are not supported. Please use 'installed' app credentials.")
        
        if 'installed' not in client_secrets:
            raise ValueError("Client secrets must be for an installed app")
            
        return client_secrets
    except Exception as e:
        raise ValueError(f"Error loading client secrets: {str(e)}")

# Function to authenticate and get service
def get_authenticated_service():
    # Load and validate client secrets
    client_secrets = get_client_config(client_secrets_path)
    
    # Create flow from the loaded client secrets
    flow = InstalledAppFlow.from_client_config(
        client_secrets,
        scopes=SCOPES
    )
    
    # Run local server flow for authentication
    credentials = flow.run_local_server(port=0)
    
    # Build services
    youtube_analytics = build('youtubeAnalytics', 'v2', credentials=credentials)
    youtube = build('youtube', 'v3', credentials=credentials)
    
    return youtube_analytics, youtube

# [Rest of your functions remain unchanged...]
# get_channel_id, fetch_analytics_data, get_video_details, main

# Execute and get datasets
try:
    print("Authenticating with YouTube API...")
    youtube_analytics, youtube = get_authenticated_service()
    print("Authentication successful. Fetching data...")
    
    daily_metrics, video_metrics, content_summary = main()
    
    # Output datasets for Power BI
    print("\nData fetch completed successfully!")
    daily_metrics
    video_metrics
    content_summary
    
except Exception as e:
    print(f"\nAn error occurred: {str(e)}")
    # Return empty DataFrames if there's an error
    pd.DataFrame(), pd.DataFrame(), pd.DataFrame()

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Import required libraries
import pandas as pd
from googleapiclient.discovery import build
from google.oauth2 import service_account
from datetime import datetime, timedelta
import os
import json

# Configuration
SERVICE_ACCOUNT_FILE = '/lakehouse/default/Files/YTPowerBi/service_account.json'  # Path to your service account JSON
CHANNEL_OWNER_EMAIL = 'arjun.ajn.m@gmail.com'  # Must be owner of the YouTube channel
SCOPES = ['https://www.googleapis.com/auth/yt-analytics.readonly',
          'https://www.googleapis.com/auth/youtube.readonly']

def get_service_account_credentials():
    """Authenticate using service account credentials."""
    try:
        # Load service account credentials from Lakehouse
        with open(SERVICE_ACCOUNT_FILE, 'r') as f:
            service_account_info = json.load(f)
        
        credentials = service_account.Credentials.from_service_account_info(
            service_account_info,
            scopes=SCOPES
        )
        
        # Service accounts need delegation for YouTube API access
        credentials = credentials.with_subject(CHANNEL_OWNER_EMAIL)
        
        return credentials
    except Exception as e:
        raise Exception(f"Service account authentication failed: {str(e)}")

def get_authenticated_service():
    """Build YouTube services using service account credentials."""
    credentials = get_service_account_credentials()
    
    # Build services
    youtube_analytics = build('youtubeAnalytics', 'v2', credentials=credentials)
    youtube = build('youtube', 'v3', credentials=credentials)
    
    return youtube_analytics, youtube

def get_channel_id(youtube_service):
    """Get channel ID for the authenticated user."""
    try:
        request = youtube_service.channels().list(
            part="id",
            mine=True
        )
        response = request.execute()
        return response['items'][0]['id']
    except Exception as e:
        raise Exception(f"Failed to get channel ID: {str(e)}")

def fetch_analytics_data(youtube_analytics, channel_id, start_date, end_date):
    """Fetch analytics data from YouTube API."""
    try:
        # Get basic metrics
        metrics_request = youtube_analytics.reports().query(
            ids=f"channel=={channel_id}",
            startDate=start_date,
            endDate=end_date,
            metrics="views,estimatedMinutesWatched,likes,subscribersGained",
            dimensions="day",
            sort="day"
        )
        metrics_response = metrics_request.execute()
        
        # Get video-level data
        video_request = youtube_analytics.reports().query(
            ids=f"channel=={channel_id}",
            startDate=start_date,
            endDate=end_date,
            metrics="views,estimatedMinutesWatched,likes,comments",
            dimensions="video",
            sort="-views",
            maxResults=200
        )
        video_response = video_request.execute()
        
        return metrics_response, video_response
    except Exception as e:
        raise Exception(f"Failed to fetch analytics data: {str(e)}")

def get_video_details(youtube_service, video_ids):
    """Get detailed information about videos."""
    video_data = []
    try:
        for i in range(0, len(video_ids), 50):
            batch = video_ids[i:i+50]
            request = youtube_service.videos().list(
                part="contentDetails,snippet,statistics",
                id=",".join(batch)
                )
            response = request.execute()
            video_data.extend(response['items'])
        return video_data
    except Exception as e:
        raise Exception(f"Failed to get video details: {str(e)}")

def main():
    """Main execution function."""
    try:
        # Authenticate and get services
        youtube_analytics, youtube = get_authenticated_service()
        
        # Get channel ID
        channel_id = get_channel_id(youtube)
        print(f"📊 Fetching data for channel ID: {channel_id}")
        
        # Set date range (last 30 days)
        end_date = datetime.now().strftime('%Y-%m-%d')
        start_date = (datetime.now() - timedelta(days=30)).strftime('%Y-%m-%d')
        
        # Fetch analytics data
        print("🔍 Fetching analytics data...")
        metrics_data, video_data = fetch_analytics_data(youtube_analytics, channel_id, start_date, end_date)
        
        # Process daily metrics
        daily_df = pd.DataFrame(metrics_data['rows'], columns=[col['name'] for col in metrics_data['columnHeaders']])
        daily_df['day'] = pd.to_datetime(daily_df['day'])
        
        # Process video data
        video_ids = [row[0] for row in video_data['rows']]
        print(f"🎬 Fetching details for {len(video_ids)} videos...")
        video_details = get_video_details(youtube, video_ids)
        
        # Create video details DataFrame
        video_list = []
        for video in video_details:
            duration = video['contentDetails']['duration']
            duration_seconds = pd.Timedelta(duration).total_seconds()
            
            video_list.append({
                'videoId': video['id'],
                'title': video['snippet']['title'],
                'duration': duration_seconds,
                'publishedAt': video['snippet']['publishedAt'],
                'views': int(video['statistics'].get('views', 0)),
                'likes': int(video['statistics'].get('likes', 0)),
                'comments': int(video['statistics'].get('comments', 0))
            })
        
        videos_df = pd.DataFrame(video_list)
        
        # Classify content type
        videos_df['content_type'] = videos_df['duration'].apply(lambda x: 'Short' if x <= 60 else 'Video')
        
        # Prepare final datasets
        print("📦 Preparing datasets for Power BI...")
        
        # 1. Daily metrics
        daily_metrics = daily_df
        
        # 2. Video metrics with content type
        video_metrics = videos_df
        
        # 3. Content type summary
        content_summary = videos_df.groupby('content_type').agg(
            total_views=('views', 'sum'),
            video_count=('videoId', 'count'),
            avg_views=('views', 'mean'),
            avg_likes=('likes', 'mean'),
            avg_comments=('comments', 'mean')
        ).reset_index()
        
        return daily_metrics, video_metrics, content_summary
        
    except Exception as e:
        print(f"❌ Error in main execution: {str(e)}")
        return pd.DataFrame(), pd.DataFrame(), pd.DataFrame()

# Execute and get datasets
try:
    daily_metrics, video_metrics, content_summary = main()
    
    # Output datasets for Power BI
    print("\n✅ Data fetch completed successfully!")
    daily_metrics
    video_metrics
    content_summary
    
except Exception as e:
    print(f"\n❌ Fatal error: {str(e)}")
    pd.DataFrame(), pd.DataFrame(), pd.DataFrame()

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

print(daily_metrics)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Import required libraries
import pandas as pd
from googleapiclient.discovery import build
from google.oauth2 import service_account
from datetime import datetime, timedelta
import json

# Configuration
SERVICE_ACCOUNT_FILE = '/lakehouse/default/Files/YTPowerBi/service_account.json'
YT_CHANNEL_ID = 'UC7YCV4bGHBh50anJ16zOkQQ'  # Manually specify your channel ID (find in YouTube Studio)

SCOPES = ['https://www.googleapis.com/auth/yt-analytics.readonly',
          'https://www.googleapis.com/auth/youtube.readonly']

def get_service_account_credentials():
    """Authenticate using service account credentials."""
    try:
        with open(SERVICE_ACCOUNT_FILE, 'r') as f:
            service_account_info = json.load(f)
        
        credentials = service_account.Credentials.from_service_account_info(
            service_account_info,
            scopes=SCOPES
        )
        return credentials
    except Exception as e:
        raise Exception(f"Service account authentication failed: {str(e)}")

def get_authenticated_service():
    """Build YouTube services using service account credentials."""
    credentials = get_service_account_credentials()
    
    # Build services
    youtube_analytics = build('youtubeAnalytics', 'v2', credentials=credentials)
    youtube = build('youtube', 'v3', credentials=credentials)
    
    return youtube_analytics, youtube

def fetch_analytics_data(youtube_analytics, channel_id, start_date, end_date):
    """Fetch analytics data from YouTube API."""
    try:
        # Get basic metrics
        metrics_request = youtube_analytics.reports().query(
            ids=f"channel=={channel_id}",
            startDate=start_date,
            endDate=end_date,
            metrics="views,estimatedMinutesWatched,likes,subscribersGained",
            dimensions="day",
            sort="day"
        )
        metrics_response = metrics_request.execute()
        
        # Get video-level data
        video_request = youtube_analytics.reports().query(
            ids=f"channel=={channel_id}",
            startDate=start_date,
            endDate=end_date,
            metrics="views,estimatedMinutesWatched,likes,comments",
            dimensions="video",
            sort="-views",
            maxResults=200
        )
        video_response = video_request.execute()
        
        return metrics_response, video_response
    except Exception as e:
        raise Exception(f"Failed to fetch analytics data: {str(e)}")

def get_video_details(youtube_service, video_ids):
    """Get detailed information about videos."""
    video_data = []
    try:
        for i in range(0, len(video_ids), 50):
            batch = video_ids[i:i+50]
            request = youtube_service.videos().list(
                part="contentDetails,snippet,statistics",
                id=",".join(batch)
                )
            response = request.execute()
            video_data.extend(response['items'])
        return video_data
    except Exception as e:
        raise Exception(f"Failed to get video details: {str(e)}")

def main():
    """Main execution function."""
    try:
        # Authenticate and get services
        youtube_analytics, youtube = get_authenticated_service()
        
        # Use pre-specified channel ID
        channel_id = YT_CHANNEL_ID
        print(f"📊 Using channel ID: {channel_id}")
        
        # Set date range (last 30 days)
        end_date = datetime.now().strftime('%Y-%m-%d')
        start_date = (datetime.now() - timedelta(days=30)).strftime('%Y-%m-%d')
        
        # Fetch analytics data
        print("🔍 Fetching analytics data...")
        metrics_data, video_data = fetch_analytics_data(youtube_analytics, channel_id, start_date, end_date)
        
        # Process daily metrics
        daily_df = pd.DataFrame(metrics_data['rows'], columns=[col['name'] for col in metrics_data['columnHeaders']])
        daily_df['day'] = pd.to_datetime(daily_df['day'])
        
        # Process video data
        video_ids = [row[0] for row in video_data['rows']]
        print(f"🎬 Fetching details for {len(video_ids)} videos...")
        video_details = get_video_details(youtube, video_ids)
        
        # Create video details DataFrame
        video_list = []
        for video in video_details:
            duration = video['contentDetails']['duration']
            duration_seconds = pd.Timedelta(duration).total_seconds()
            
            video_list.append({
                'videoId': video['id'],
                'title': video['snippet']['title'],
                'duration': duration_seconds,
                'publishedAt': video['snippet']['publishedAt'],
                'views': int(video['statistics'].get('views', 0)),
                'likes': int(video['statistics'].get('likes', 0)),
                'comments': int(video['statistics'].get('comments', 0))
            })
        
        videos_df = pd.DataFrame(video_list)
        
        # Classify content type
        videos_df['content_type'] = videos_df['duration'].apply(lambda x: 'Short' if x <= 60 else 'Video')
        
        # Prepare final datasets
        print("📦 Preparing datasets for Power BI...")
        
        return daily_df, videos_df, videos_df.groupby('content_type').agg(
            total_views=('views', 'sum'),
            video_count=('videoId', 'count'),
            avg_views=('views', 'mean'),
            avg_likes=('likes', 'mean'),
            avg_comments=('comments', 'mean')
        ).reset_index()
        
    except Exception as e:
        print(f"❌ Error: {str(e)}")
        return pd.DataFrame(), pd.DataFrame(), pd.DataFrame()

# Execute
daily_metrics, video_metrics, content_summary = main()

# Output datasets for Power BI
daily_metrics
video_metrics
content_summary

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Import required libraries
import pandas as pd
from googleapiclient.discovery import build
from google.oauth2 import service_account
from datetime import datetime, timedelta
import json

# Configuration
SERVICE_ACCOUNT_FILE = '/lakehouse/default/Files/YTPowerBi/service_account.json'
YT_CHANNEL_ID = 'UC7YCV4bGHBh50anJ16zOkQQ'  # Replace with your channel ID
SERVICE_ACCOUNT_EMAIL = 'fabric-yt-analytics-agent@shaped-complex-315416.iam.gserviceaccount.com'  # From JSON file
SCOPES = ['https://www.googleapis.com/auth/yt-analytics.readonly',
          'https://www.googleapis.com/auth/youtube.readonly']

def get_authenticated_service():
    """Build YouTube services with proper authentication."""
    try:
        # Load service account credentials
        with open(SERVICE_ACCOUNT_FILE, 'r') as f:
            service_account_info = json.load(f)
        
        credentials = service_account.Credentials.from_service_account_info(
            service_account_info,
            scopes=SCOPES
        )
        
        # Build services
        youtube_analytics = build('youtubeAnalytics', 'v2', credentials=credentials)
        youtube = build('youtube', 'v3', credentials=credentials)
        
        return youtube_analytics, youtube
    except Exception as e:
        raise Exception(f"Authentication failed: {str(e)}")

def fetch_analytics_data(youtube_analytics, channel_id, start_date, end_date):
    """Fetch analytics data with proper error handling."""
    try:
        # Basic channel metrics
        metrics_request = youtube_analytics.reports().query(
            ids=f"channel=={channel_id}",
            startDate=start_date,
            endDate=end_date,
            metrics="views,estimatedMinutesWatched,likes,subscribersGained",
            dimensions="day",
            sort="day"
        )
        metrics_response = metrics_request.execute()
        
        # Video-level metrics
        video_request = youtube_analytics.reports().query(
            ids=f"channel=={channel_id}",
            startDate=start_date,
            endDate=end_date,
            metrics="views,estimatedMinutesWatched,likes,comments",
            dimensions="video",
            sort="-views",
            maxResults=200
        )
        video_response = video_request.execute()
        
        return metrics_response, video_response
    except Exception as e:
        raise Exception(f"API request failed. Ensure:\n"
                      f"1. Service account {SERVICE_ACCOUNT_EMAIL} is added as an owner to channel {YT_CHANNEL_ID}\n"
                      f"2. YouTube Analytics API is enabled\n"
                      f"3. Proper scopes are requested\n"
                      f"Error details: {str(e)}")

def main():
    """Main execution with comprehensive error handling."""
    try:
        # Authenticate
        youtube_analytics, youtube = get_authenticated_service()
        print("✅ Authentication successful")
        
        # Set date range (last 30 days)
        end_date = datetime.now().strftime('%Y-%m-%d')
        start_date = (datetime.now() - timedelta(days=30)).strftime('%Y-%m-%d')
        
        # Fetch data
        print("📊 Fetching analytics data...")
        metrics_data, video_data = fetch_analytics_data(youtube_analytics, YT_CHANNEL_ID, start_date, end_date)
        
        # Process data
        daily_df = pd.DataFrame(metrics_data['rows'], columns=[col['name'] for col in metrics_data['columnHeaders']])
        daily_df['day'] = pd.to_datetime(daily_df['day'])
        
        video_ids = [row[0] for row in video_data['rows']]
        print(f"🎥 Processing {len(video_ids)} videos...")
        
        # Get video details in batches
        video_details = []
        for i in range(0, len(video_ids), 50):
            batch = video_ids[i:i+50]
            request = youtube.videos().list(
                part="contentDetails,snippet,statistics",
                id=",".join(batch)
            )
            response = request.execute()
            video_details.extend(response['items'])
        
        # Create video DataFrame
        videos_df = pd.DataFrame([{
            'videoId': v['id'],
            'title': v['snippet']['title'],
            'duration': pd.Timedelta(v['contentDetails']['duration']).total_seconds(),
            'publishedAt': v['snippet']['publishedAt'],
            'views': int(v['statistics'].get('views', 0)),
            'likes': int(v['statistics'].get('likes', 0)),
            'comments': int(v['statistics'].get('comments', 0))
        } for v in video_details])
        
        # Classify content
        videos_df['content_type'] = videos_df['duration'].apply(lambda x: 'Short' if x <= 60 else 'Video')
        
        # Create summary
        content_summary = videos_df.groupby('content_type').agg(
            total_views=('views', 'sum'),
            video_count=('videoId', 'count'),
            avg_views=('views', 'mean'),
            avg_likes=('likes', 'mean'),
            avg_comments=('comments', 'mean')
        ).reset_index()
        
        return daily_df, videos_df, content_summary
        
    except Exception as e:
        print(f"❌ Error: {str(e)}")
        return pd.DataFrame(), pd.DataFrame(), pd.DataFrame()

# Execute and display results
daily_metrics, video_metrics, content_summary = main()
daily_metrics
video_metrics
content_summary

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Import required libraries
import pandas as pd
from googleapiclient.discovery import build
from google_auth_oauthlib.flow import InstalledAppFlow
from datetime import datetime, timedelta
import json
import os

# Configuration
CLIENT_SECRETS_FILE = '/lakehouse/default/Files/YTPowerBi/client_secret_desktop.json'  # OAuth 2.0 credentials
SCOPES = ['https://www.googleapis.com/auth/yt-analytics.readonly',
          'https://www.googleapis.com/auth/youtube.readonly']

def get_authenticated_service():
    """Authenticate using OAuth 2.0 flow."""
    try:
        # Load client secrets
        with open(CLIENT_SECRETS_FILE, 'r') as f:
            client_secrets = json.load(f)
        
        # Check for proper client secrets format
        if 'installed' not in client_secrets:
            if 'web' in client_secrets:
                client_secrets['installed'] = client_secrets.pop('web')
            else:
                raise ValueError("Client secrets must be for an installed app")
        
        # Create flow from client secrets
        flow = InstalledAppFlow.from_client_config(
            client_secrets,
            scopes=SCOPES
        )
        
        # Run local server flow
        credentials = flow.run_local_server(port=0)
        
        # Build services
        youtube_analytics = build('youtubeAnalytics', 'v2', credentials=credentials)
        youtube = build('youtube', 'v3', credentials=credentials)
        
        return youtube_analytics, youtube
    except Exception as e:
        raise Exception(f"Authentication failed: {str(e)}")

def get_channel_id(youtube_service):
    """Get channel ID for the authenticated user."""
    try:
        request = youtube_service.channels().list(
            part="id",
            mine=True
        )
        response = request.execute()
        return response['items'][0]['id']
    except Exception as e:
        raise Exception(f"Failed to get channel ID: {str(e)}")

def fetch_analytics_data(youtube_analytics, channel_id, start_date, end_date):
    """Fetch analytics data with proper error handling."""
    try:
        # Basic metrics
        metrics_response = youtube_analytics.reports().query(
            ids=f"channel=={channel_id}",
            startDate=start_date,
            endDate=end_date,
            metrics="views,estimatedMinutesWatched,likes,subscribersGained",
            dimensions="day",
            sort="day"
        ).execute()
        
        # Video-level data
        video_response = youtube_analytics.reports().query(
            ids=f"channel=={channel_id}",
            startDate=start_date,
            endDate=end_date,
            metrics="views,estimatedMinutesWatched,likes,comments",
            dimensions="video",
            sort="-views",
            maxResults=200
        ).execute()
        
        return metrics_response, video_response
    except Exception as e:
        raise Exception(f"Failed to fetch analytics data: {str(e)}")

def main():
    """Main execution with comprehensive error handling."""
    try:
        # Authenticate
        youtube_analytics, youtube = get_authenticated_service()
        print("✅ Authentication successful")
        
        # Get channel ID
        channel_id = get_channel_id(youtube)
        print(f"📊 Fetching data for channel ID: {channel_id}")
        
        # Set date range (last 30 days)
        end_date = datetime.now().strftime('%Y-%m-%d')
        start_date = (datetime.now() - timedelta(days=30)).strftime('%Y-%m-%d')
        
        # Fetch data
        print("🔍 Fetching analytics data...")
        metrics_data, video_data = fetch_analytics_data(youtube_analytics, channel_id, start_date, end_date)
        
        # Process daily metrics
        daily_df = pd.DataFrame(metrics_data['rows'], columns=[col['name'] for col in metrics_data['columnHeaders']])
        daily_df['day'] = pd.to_datetime(daily_df['day'])
        
        # Process video data
        video_ids = [row[0] for row in video_data['rows']]
        print(f"🎥 Processing {len(video_ids)} videos...")
        
        # Get video details in batches
        video_details = []
        for i in range(0, len(video_ids), 50):
            batch = video_ids[i:i+50]
            response = youtube.videos().list(
                part="contentDetails,snippet,statistics",
                id=",".join(batch)
            ).execute()
            video_details.extend(response['items'])
        
        # Create video DataFrame
        videos_df = pd.DataFrame([{
            'videoId': v['id'],
            'title': v['snippet']['title'],
            'duration': pd.Timedelta(v['contentDetails']['duration']).total_seconds(),
            'publishedAt': v['snippet']['publishedAt'],
            'views': int(v['statistics'].get('views', 0)),
            'likes': int(v['statistics'].get('likes', 0)),
            'comments': int(v['statistics'].get('comments', 0))
        } for v in video_details])
        
        # Classify content
        videos_df['content_type'] = videos_df['duration'].apply(lambda x: 'Short' if x <= 60 else 'Video')
        
        # Create summary
        content_summary = videos_df.groupby('content_type').agg(
            total_views=('views', 'sum'),
            video_count=('videoId', 'count'),
            avg_views=('views', 'mean'),
            avg_likes=('likes', 'mean'),
            avg_comments=('comments', 'mean')
        ).reset_index()
        
        return daily_df, videos_df, content_summary
        
    except Exception as e:
        print(f"❌ Error: {str(e)}")
        return pd.DataFrame(), pd.DataFrame(), pd.DataFrame()

# Execute
daily_metrics, video_metrics, content_summary = main()

# Output datasets for Power BI
daily_metrics
video_metrics
content_summary

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

import isodate

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
