# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "ef13f88d-d179-4002-acb4-91ec1a61690c",
# META       "default_lakehouse_name": "Learning_Lakehouse",
# META       "default_lakehouse_workspace_id": "bc05e361-9f49-4f28-ae66-87d8e1968bd9",
# META       "known_lakehouses": [
# META         {
# META           "id": "ef13f88d-d179-4002-acb4-91ec1a61690c"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

# Welcome to your new notebook
# Type here in the cell editor to add code!


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

from pyspark.sql.functions import col, to_timestamp, date_format, udf
from pyspark.sql.types import IntegerType
import isodate

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Step 1: Load raw data from yt_videostats
def load_raw_table():
    return spark.table("Learning_Lakehouse.yt_videos_metadata")


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def parse_duration(duration_str):
    try:
        return int(isodate.parse_duration(duration_str).total_seconds())
    except:
        return 0


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Step 2: Transform - Extract capture_date and capture_time
def transform_dataframe(df_raw):
    parse_duration_udf = udf(parse_duration, IntegerType())

    df_transformed = (
        df_raw.withColumn("duration_seconds", parse_duration_udf(col("duration")))
              .withColumn("is_short", col("duration_seconds") <= 60)
              .withColumn("capture_datetime", to_timestamp("timestamp", "yyyy-MM-dd HH:mm:ss"))
              .withColumn("capture_date", date_format(col("capture_datetime"), "yyyy-MM-dd"))
              .withColumn("capture_time", date_format(col("capture_datetime"), "HH:mm:ss"))
              .drop("capture_datetime")
    )
    return df_transformed

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Step 3: Append transformed data to video_stats table
def write_to_video_stats(df_transformed):
    df_transformed.write.mode("append").saveAsTable("Learning_Lakehouse.gold_yt_videos_metadata")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# # Step 4: Clear the source table yt_videostats
# def clear_raw_table():
#     spark.sql("DELETE FROM Learning_Lakehouse.yt_videostats")

# CELL ********************

df_raw = load_raw_table()
df_transformed = transform_dataframe(df_raw)
# write_to_video_stats(df_transformed)
# clear_raw_table()  # Not required for now

print("✅ ETL complete: Data moved to 'video_stats' and 'yt_videostats' cleared.")


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

write_to_video_stats(df_transformed)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

df_transformed = transform_dataframe(df_raw)
df_transformed.show()

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
