# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "ef13f88d-d179-4002-acb4-91ec1a61690c",
# META       "default_lakehouse_name": "Learning_Lakehouse",
# META       "default_lakehouse_workspace_id": "bc05e361-9f49-4f28-ae66-87d8e1968bd9",
# META       "known_lakehouses": [
# META         {
# META           "id": "ef13f88d-d179-4002-acb4-91ec1a61690c"
# META         }
# META       ]
# META     },
# META     "environment": {
# META       "environmentId": "57f9b112-9748-aa7c-4d32-13d818108dcd",
# META       "workspaceId": "00000000-0000-0000-0000-000000000000"
# META     }
# META   }
# META }

# CELL ********************

# Not required as environment is configured
# %pip install --upgrade google-api-python-client

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Required external Libraries
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build

# Built in libraries
from datetime import datetime
import pandas as pd

# for computing duration
import isodate

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Your YouTube API key and Channel ID
API_KEY = 'AIzaSyCnYeVgZH9GeHlhyh5ZJELjtVIBqrrTUB4'
CHANNEL_ID = 'UC7YCV4bGHBh50anJ16zOkQQ'


# Path to your client_secrets.json
CLIENT_SECRET_FILE = 'client_secrets.json'

# Scopes for YouTube Data + Analytics
SCOPES = [
    'https://www.googleapis.com/auth/yt-analytics.readonly',
    'https://www.googleapis.com/auth/youtube.readonly'
]

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# YouTube API call to get all videos from your channel
def get_channel_videos(api_key, channel_id):
    youtube = build('youtube', 'v3', developerKey=api_key)
    videos = []
    next_page_token = None

    while True:
        res = youtube.search().list(
            channelId=channel_id,
            part='id',
            order='date',
            maxResults=50,
            pageToken=next_page_token,
            type='video'
        ).execute()

        for item in res['items']:
            videos.append(item['id']['videoId'])

        next_page_token = res.get('nextPageToken')
        if not next_page_token:
            break

    return videos

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Function to get only video_id, title, duration, and published date
def get_video_basic_info(api_key, video_ids):
    youtube = build('youtube', 'v3', developerKey=api_key)
    basic_info = []

    for i in range(0, len(video_ids), 50):  # API limit is 50 IDs per call
        response = youtube.videos().list(
            part='snippet,contentDetails',
            id=','.join(video_ids[i:i+50])
        ).execute()

        for item in response['items']:
            basic_info.append({
                'video_id': item['id'],
                'title': item['snippet']['title'],
                'duration': item['contentDetails']['duration'],  # ISO 8601 format
                'published_at': item['snippet']['publishedAt'],  # ISO 8601 format
            })

    return basic_info


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def get_video_stats(api_key, video_ids):
    youtube = build('youtube', 'v3', developerKey=api_key)
    stats = []

    for i in range(0, len(video_ids), 50):
        response = youtube.videos().list(
            part='statistics,snippet,contentDetails',
            id=','.join(video_ids[i:i+50])
        ).execute()

        for item in response['items']:
            stats.append({
                'video_id': item['id'],
                'title': item['snippet']['title'],
                'views': int(item['statistics'].get('viewCount', 0)),
                'likes': int(item['statistics'].get('likeCount', 0)),
                
            })

    return stats


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Convert the data into a Spark DataFrame for storage
def view_data_to_lakehouse(data):
    timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

    # Convert to DataFrame if it's a list of dicts
    if isinstance(data, list):
        df = pd.DataFrame(data)
    else:
        df = data

    df['timestamp'] = timestamp

    # Convert to Spark DataFrame
    spark_df = spark.createDataFrame(df)

    # Write to Lakehouse table
    spark_df.show()

    # print(f"✅ Logged {len(df)} records to '{table_name}' using mode '{write_mode}' at {timestamp}")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Convert the data into a Spark DataFrame for storage
def log_data_to_lakehouse(data, table_name, write_mode="append"):
    timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

    # Convert to DataFrame if it's a list of dicts
    if isinstance(data, list):
        df = pd.DataFrame(data)
    else:
        df = data

    df['timestamp'] = timestamp

    # Convert to Spark DataFrame
    spark_df = spark.createDataFrame(df)

    # Write to Lakehouse table
    spark_df.write.mode(write_mode).saveAsTable(table_name)

    print(f"✅ Logged {len(df)} records to '{table_name}' using mode '{write_mode}' at {timestamp}")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Main logic to fetch and store YouTube data
video_ids = get_channel_videos(API_KEY, CHANNEL_ID)
video_info = get_video_basic_info(API_KEY, video_ids)
video_stats = get_video_stats(API_KEY, video_ids)
# log_data_to_lakehouse(yt_videostats, "Learning_Lakehouse.YT_VideoStats", "append")
# log_data_to_lakehouse(metadata, "Learning_Lakehouse.video_metadata", "overwrite")
# log_stats_to_lakehouse(yt_video_stats)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

view_data_to_lakehouse(video_info), view_data_to_lakehouse(video_stats)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark",
# META   "frozen": true,
# META   "editable": false
# META }
