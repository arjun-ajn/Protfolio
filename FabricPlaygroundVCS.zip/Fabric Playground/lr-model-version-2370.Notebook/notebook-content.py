# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "ef13f88d-d179-4002-acb4-91ec1a61690c",
# META       "default_lakehouse_name": "Learning_Lakehouse",
# META       "default_lakehouse_workspace_id": "bc05e361-9f49-4f28-ae66-87d8e1968bd9"
# META     }
# META   }
# META }

# MARKDOWN ********************

# # Track Machine Learning experiments and models
# 
# A machine learning model is a file that has been trained to recognize certain types of patterns. You train a model over a set of data, providing it an algorithm that it can use to reason over and learn from those data. Once you have trained the model, you can use it to reason over data that it hasn't seen before, and make predictions about that data.
# 
# In this notebook, you will learn the basic steps to run an experiment, add a model version to track run metrics and parameters and register a model.


# MARKDOWN ********************

# REF : https://medium.com/@sarakarim/train-and-evaluate-a-classification-model-in-machine-learning-18fbd6504da3

# CELL ********************

import mlflow

# Set given experiment as the active experiment. If an experiment with this name does not exist, a new experiment with this name is created.
mlflow.set_experiment("Cashflow Classification")


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

import pandas as pd
from pyspark.sql.functions import col
from pyspark.sql.types import StringType
import pyspark.pandas as ps
from pyspark.sql.functions import *
from pyspark.sql import functions as F

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

pip install xlrd

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Set up the file path and sheet name
excel_file_path = "abfss://bc05e361-9f49-4f28-ae66-87d8e1968bd9@onelake.dfs.fabric.microsoft.com/ef13f88d-d179-4002-acb4-91ec1a61690c/Files/Expenses/All Transactions.xlsx"
excel_sheet_name = "All Transactions"

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

from collections import defaultdict
types = defaultdict(str)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Set up the options and read the file
options = dict(header=0, keep_default_na=False, engine="openpyxl")
df_pandas = pd.read_excel(excel_file_path, sheet_name=excel_sheet_name, dtype=types, **options)
df_pandas.columns

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

features = ['PARTICULARS']
labels = 'Transaction Mode'

X, y = df_pandas[features].values, df_pandas[labels].values

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

import mlflow.sklearn
import numpy as np
from sklearn.linear_model import LogisticRegression
from mlflow.models.signature import infer_signature

# Start your training job with `start_run()`
with mlflow.start_run() as run:

    lr = LogisticRegression()
    X = np.array([-2, -1, 0, 1, 2, 1]).reshape(-1, 1)
    y = np.array([0, 0, 1, 1, 1, 0])
    lr.fit(X, y)
    score = lr.score(X, y)
    signature = infer_signature(X, y)

    # Activate the MLFlow logging API to log your training job metrics
    print("test log_metrics.")
    mlflow.log_metric("score", score)

    # Activate the MLFlow logging API to log your training job parameters
    print("test log_params.")
    mlflow.log_param("alpha", "alpha")

    # Activate the MLFlow logging API to log your model artifacts
    print("test log_model.")
    mlflow.sklearn.log_model(lr, "Cashflow", signature=signature)
    print("Model saved in run_id=%s" % run.info.run_id)
    
    # Register the model produced from your training job.
    print("test register_model.")
    mlflow.register_model(
        "runs:/{}/Cashflow".format(run.info.run_id), "Cashflow"
    )
    print("All done")


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
