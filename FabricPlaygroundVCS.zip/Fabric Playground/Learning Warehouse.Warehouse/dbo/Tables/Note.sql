CREATE TABLE [dbo].[Note] (

	[Sr no] bigint NULL, 
	[Concepts & Confidentiality] varchar(4000) NULL, 
	[Description] varchar(4000) NULL
);