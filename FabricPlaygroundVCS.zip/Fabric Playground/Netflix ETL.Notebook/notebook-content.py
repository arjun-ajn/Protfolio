# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "db82b7ae-c3f6-4f00-b540-4940576fcaff",
# META       "default_lakehouse_name": "DataflowsStagingLakehouse_a602367c568b46f8875d9f7a48b477ab",
# META       "default_lakehouse_workspace_id": "bc05e361-9f49-4f28-ae66-87d8e1968bd9",
# META       "known_lakehouses": [
# META         {
# META           "id": "db82b7ae-c3f6-4f00-b540-4940576fcaff"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

%pip install semantic-link

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

import pandas as pd
import sempy.fabric as fabric
spark.conf.set("spark.sql.catalog.pbi", "com.microsoft.azure.synapse.ml.powerbi.PowerBICatalog")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

df_datasets = fabric.list_datasets()
df_datasets

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# df_tables = fabric.list_tables("Netflix Dataset", include_columns=True)
df_tables = fabric.list_tables("Netflix Dataset")
df_tables["Name"]

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Initialiize dataset
df = pd.DataFrame()

# group all related source files in a list to get data from all realated files
listDeviceFiles = [fn for fn in df_tables["Name"] if "Devices" in fn]
listProfileFiles = [fn for fn in df_tables["Name"] if "Profiles" in fn]
listClickstreamFiles = [fn for fn in df_tables["Name"] if "Clickstream" in fn]

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

df_table = fabric.read_table("Netflix Dataset", "Clickstreams1")
df_table.shape
df_table = fabric.read_table("Netflix Dataset", "Clickstreams2")
df_table.shape

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# read all Profiles files
datalist = [fabric.read_table("Netflix Dataset", fn) for fn in df_tables["Name"] if "Profiles" in fn]
df = pd.concat(datalist)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# read all Clickstream files
datalist = [fabric.read_table("Netflix Dataset", fn) for fn in df_tables["Name"] if "Clickstream" in fn]
df = pd.concat(datalist)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

df["Source"]

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Replace "Source" value with key "Source" suffixed by index of the source name
listSources=list(df['Source'].value_counts().index)
sourceDict={source:"Source " + str(listSources.index(source)) for source in listSources}
df.replace({"Source": sourceDict},inplace=True)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

df.head()

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

df.to_lakehouse_table("All_Clickstream")
# write.mode("overwrite").format("delta").saveAsTable("All Clickstream")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
