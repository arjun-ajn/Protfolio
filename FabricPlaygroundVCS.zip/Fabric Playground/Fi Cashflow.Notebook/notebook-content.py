# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "ef13f88d-d179-4002-acb4-91ec1a61690c",
# META       "default_lakehouse_name": "Learning_Lakehouse",
# META       "default_lakehouse_workspace_id": "bc05e361-9f49-4f28-ae66-87d8e1968bd9",
# META       "known_lakehouses": [
# META         {
# META           "id": "ef13f88d-d179-4002-acb4-91ec1a61690c"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

!pip uninstall tabula -y  # if you have the wrong 'tabula' installed
!pip uninstall tabula-py -y  # to remove a possibly broken tabula-py installation

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

!pip install tabula-py

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

!java -version

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

import pandas as pd
import tabula

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

!pip show tabula-py

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

tabula.environment_info()

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

dfs = tabula.read_pdf('abfss://bc05e361-9f49-4f28-ae66-87d8e1968bd9@onelake.dfs.fabric.microsoft.com/ef13f88d-d179-4002-acb4-91ec1a61690c/Files/Expenses/01 Jul 2024 - 31 Jul 2024.pdf', pages=1)
len(dfs)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

!pip install PyMuPDF

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

import fitz  # PyMuPDF

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

pdf_path = "/lakehouse/default/Files/Expenses/01 Jul 2024 - 31 Jul 2024.pdf"
doc = fitz.open(pdf_path)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Extract text from all pages
text = ""
for page_num in range(len(doc)):
    page = doc.load_page(page_num)  # Load each page
    text += page.get_text("text")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Example: Convert text into a DataFrame (customize based on content)
data = text.split('\n')  # Example: splitting text lines
df = pd.DataFrame(data, columns=["Text"])

df.head()  # Check the DataFrame

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

display(df)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
