# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "ef13f88d-d179-4002-acb4-91ec1a61690c",
# META       "default_lakehouse_name": "Learning_Lakehouse",
# META       "default_lakehouse_workspace_id": "bc05e361-9f49-4f28-ae66-87d8e1968bd9"
# META     }
# META   }
# META }

# CELL ********************

#########################################################################################
# Read secretes from Azure Key Vault
#########################################################################################

'''
key_vault = "https://dgosbellKeyVault.vault.azure.net/"
tenant = mssparkutils.credentials.getSecret(key_vault , "FabricTenantId")
client = mssparkutils.credentials.getSecret(key_vault , "FabricClientId")
client_secret = mssparkutils.credentials.getSecret(key_vault , "FabricClientSecret")
'''
tenant = "3c506d3a-59ac-4090-9034-a1230e5c4fc0"
client = "81cb5565-c23e-4605-bb50-b816bace63f5"
client_secret = "Jg3TOoE4Ig4+8WdW/PCDyNJkV5vXrEmLT5ksVmH0fpo="

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************


#########################################################################################
# Authentication - Replace string variables with your relevant values       
#########################################################################################
 
import json, requests, pandas as pd
import datetime
 
try:
    from azure.identity import ClientSecretCredential
except Exception:
     !pip install azure.identity
     from azure.identity import ClientSecretCredential
 


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Generates the access token for the Service Principal
api = 'https://analysis.windows.net/powerbi/api/.default'
auth = ClientSecretCredential(authority = 'https://login.microsoftonline.com/',
                              tenant_id = tenant,
                              client_id = client,
                              client_secret = client_secret)
access_token = auth.get_token(api)
access_token = access_token.token
 
print('\nSuccessfully authenticated.')  

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

 
 
#########################################################################################
# Get Refreshables
#########################################################################################

base_urls = {'powerbi':'https://api.powerbi.com/v1.0/myorg/', 'fabric':'https://api.fabric.microsoft.com/v1/'}
base_url = 'https://api.powerbi.com/v1.0/myorg/'
fabric_url='https://api.fabric.microsoft.com/v1/'
header = {'Authorization': f'Bearer {access_token}'}

fabric_paths={'workspace':"workspaces"}
powerbi_paths={'groups':"groups", 'datasets':"datasets", 'adminReport':"admin/reports", 'refreshables':"admin/capacities/refreshables"}



# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

from pyspark.sql.functions import *
import requests, os, datetime
from delta.tables import *

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def get_response(base_url, relative_path):
    response=requests.get(base_url + relative_path, headers=header)
    return response

def response_to_df(response):
    contentRDD = spark.sparkContext.parallelize([response.content.decode()])
    dfContent = spark.read.json(contentRDD)
    return dfContent

def createTable(dfResponse, tableName):
    ## write the spark dataframe out to a delta table
    if spark.catalog.tableExists(tableName):
            #get existing table
            targetTable = DeltaTable.forName(spark,tableName)
            #merge into table
            (targetTable.alias("t")
                .merge(dfResponse.alias("s"), "s.Id = t.Id")
                .whenMatchedUpdateAll()
                .whenNotMatchedInsertAll()
                .execute()
            )
    else:
        # create workspace table
        dfResponse.write.mode('overwrite').format("delta").saveAsTable(tableName)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

display(dfResponse)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

#########################################################################################
# For each power bi path, generate tables
#########################################################################################
for key, value in powerbi_paths.items():
    response_content=get_response(base_urls.get('powerbi'), value)
    if (response_content.status_code == 200):
        dfResponse=response_to_df(response_content)
        dfResponse=dfResponse.select(explode("value")) \
            .select("col.*"
                )
        createTable(dfResponse, key)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# BELOW CODES ARE FOR TESTING

# CELL ********************

refreshesRDD = spark.sparkContext.parallelize([refreshables_response.content.decode()])
dfrefreshes = spark.read.json(refreshesRDD)
dfrefreshes=dfrefreshes.select(explode("value")) \
            .select("col.*"
                )
display(dfrefreshes)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

createTable(dfrefreshes, "refreshes")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

response_content=get_response(base_url,refreshables_url)
dfResponse=response_to_df(response_content)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

print(base_urls.get('fabric','not in dictionary'))

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

refreshables_url = "admin/capacities/refreshables?$top=200"
groups_url = "groups"
workspaces_url = "workspaces"
datasets_url="datasets"
reports_url="admin/reports"

refreshables_response = requests.get(base_url + refreshables_url, headers=header)
groups_response = requests.get(base_url + groups_url, headers=header)
workspaces_response = requests.get(fabric_url + workspaces_url, headers=header)
datasets_response = requests.get(base_url + datasets_url, headers=header)
reports_response = requests.get(base_url + reports_url, headers=header)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

print(workspaces_response.status_code)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

display(dfrefreshes)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

from pyspark.sql.functions import *
import requests, os, datetime
from delta.tables import *

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

workspacesRDD = spark.sparkContext.parallelize([workspaces_response.content.decode()])
dfWorkspaces = spark.read.json(workspacesRDD)

groupsRDD = spark.sparkContext.parallelize([groups_response.content.decode()])
dfGroups = spark.read.json(groupsRDD)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

dfWorkspaces = dfWorkspaces.select(explode("value")) \
    .select("col.id", 
        "col.description", 
        "col.displayName"
        )

dfGroups = dfGroups.select(explode("value")) \
    .select("col.id", 
        "col.name", 
        "col.isReadOnly",
        "col.type",
        "col.isOnDedicatedCapacity"
        )


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

## write the spark dataframe out to a delta table
if spark.catalog.tableExists("Workspaces"):
        #get existing table
        targetTable = DeltaTable.forName(spark,"Workspaces")
        #merge into table
        (targetTable.alias("t")
            .merge(dfRefreshables.alias("s"), "s.Id = t.Id")
            .whenMatchedUpdateAll()
            .whenNotMatchedInsertAll()
            .execute()
        )
else:
    # create workspace table
    dfWorkspaces.write.mode('overwrite').format("delta").saveAsTable("Workspaces")

## write the spark dataframe out to a delta table
if spark.catalog.tableExists("Groups"):
        #get existing table
        targetTable = DeltaTable.forName(spark,"Groups")
        #merge into table
        (targetTable.alias("t")
            .merge(dfRefreshables.alias("s"), "s.Id = t.Id")
            .whenMatchedUpdateAll()
            .whenNotMatchedInsertAll()
            .execute()
        )
else:
    # create workspace table
    dfGroups.write.mode('overwrite').format("delta").saveAsTable("Groups")


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# write raw data to a json file
with open("/lakehouse/default/Files/Power Bi REST API/groups.json", 'wb') as f:
    f.write(groups_response.content)

with open("/lakehouse/default/Files/Power Bi REST API/workspaces.json", 'wb') as f:
    f.write(workspaces_response.content)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# write raw data to a json file
# Not required for now
'''
requestDate = datetime.datetime.now()
outputFilePath = "//lakehouse/default/Files/refreshables/top_200_{year}{month}{day}.json".format(year = requestDate.strftime("%Y"), month= requestDate.strftime("%m"), day=requestDate.strftime("%d"))
 
if not os.path.exists(os.path.dirname(outputFilePath)):    
    print("creating folder: " + os.path.dirname(outputFilePath))    
    os.makedirs(os.path.dirname(outputFilePath), exist_ok=True)
 
with open(outputFilePath, 'wb') as f:
    f.write(refreshables_response.content)
'''

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
