# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "ef13f88d-d179-4002-acb4-91ec1a61690c",
# META       "default_lakehouse_name": "Learning_Lakehouse",
# META       "default_lakehouse_workspace_id": "bc05e361-9f49-4f28-ae66-87d8e1968bd9"
# META     }
# META   }
# META }

# CELL ********************

#########################################################################################
# Read secretes from Azure Key Vault
#########################################################################################

'''
key_vault = "https://dgosbellKeyVault.vault.azure.net/"
tenant = mssparkutils.credentials.getSecret(key_vault , "FabricTenantId")
client = mssparkutils.credentials.getSecret(key_vault , "FabricClientId")
client_secret = mssparkutils.credentials.getSecret(key_vault , "FabricClientSecret")
'''
tenant = "3c506d3a-59ac-4090-9034-a1230e5c4fc0"
client = "81cb5565-c23e-4605-bb50-b816bace63f5"
client_secret = "Jg3TOoE4Ig4+8WdW/PCDyNJkV5vXrEmLT5ksVmH0fpo="

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************


#########################################################################################
# Authentication - Replace string variables with your relevant values       
#########################################################################################
 
import json, requests, pandas as pd
import datetime, pytz
 
try:
    from azure.identity import ClientSecretCredential
except Exception:
     !pip install azure.identity
     from azure.identity import ClientSecretCredential


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Generates the access token for the Service Principal
api = 'https://analysis.windows.net/powerbi/api/.default'
auth = ClientSecretCredential(authority = 'https://login.microsoftonline.com/',
                              tenant_id = tenant,
                              client_id = client,
                              client_secret = client_secret)
access_token = auth.get_token(api)
access_token = access_token.token
 
print('\nSuccessfully authenticated.')  

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

 
 
#########################################################################################
# Get Refreshables
#########################################################################################

header = {'Authorization': f'Bearer {access_token}'}

base_url = 'https://api.powerbi.com/v1.0/myorg/'
fabric_url='https://api.fabric.microsoft.com/v1/'

base_urls = {'powerbi':'https://api.powerbi.com/v1.0/myorg/', 'fabric':'https://api.fabric.microsoft.com/v1/'}

powerbi_paths={
    'groups':"groups"
    , 'datasets':"datasets"
    , 'adminReport':"admin/reports"
    # , 'refreshables':"admin/capacities/refreshables"
    }
fabric_paths={'workspace':"workspaces"}

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

from pyspark.sql.functions import *
import requests, os, datetime
from delta.tables import *

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def get_response(base_url, relative_path):
    response=requests.get(base_url + relative_path, headers=header)
    return response

def response_to_df(response):
    contentRDD = spark.sparkContext.parallelize([response.content.decode()])
    dfContent = spark.read.json(contentRDD)
    return dfContent

def createTable(dfResponse, tableName):
    # Get current timestamp based on timezone
    timezone_str='Asia/Kolkata'
    timezone = pytz.timezone(timezone_str)
    local_time = datetime.datetime.now(timezone)

    dfResponse=dfResponse.withColumn("etl_timestamp", lit(str(local_time)))

    ## write the spark dataframe out to a delta table
    if spark.catalog.tableExists(tableName):
            #get existing table
            targetTable = DeltaTable.forName(spark,tableName)
            #merge into table
            (targetTable.alias("t")
                .merge(dfResponse.alias("s"), "s.Id = t.Id")
                .whenMatchedUpdateAll()
                .whenNotMatchedInsertAll()
                .execute()
            )
    else:
        # create workspace table
        dfResponse.write.mode('overwrite').format("delta").saveAsTable(tableName)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

#########################################################################################
# For each power bi path, generate tables
#########################################################################################
for key, value in powerbi_paths.items():
    response_content=get_response(base_urls.get('powerbi'), value)
    print(key, "-", value)
    if (response_content.status_code == 200):
        dfResponse=response_to_df(response_content)
        dfResponse=dfResponse.select(explode("value")) \
            .select("col.*"
                )
        createTable(dfResponse, key)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

display(dfResponse)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
