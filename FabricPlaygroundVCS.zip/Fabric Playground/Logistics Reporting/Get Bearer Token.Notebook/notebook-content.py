# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {}
# META }

# MARKDOWN ********************

# This notebook is to generate a bearer token for sharepoint data copy activity

# CELL ********************

# REF URL: https://www.youtube.com/watch?v=7zrn149sniY

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

#########################################################################################
# Read secretes from Azure Key Vault
#########################################################################################

'''
key_vault = "https://dgosbellKeyVault.vault.azure.net/"
tenant = mssparkutils.credentials.getSecret(key_vault , "FabricTenantId")
client = mssparkutils.credentials.getSecret(key_vault , "FabricClientId")
client_secret = mssparkutils.credentials.getSecret(key_vault , "FabricClientSecret")
'''
tenant = "3c506d3a-59ac-4090-9034-a1230e5c4fc0"
client = "81cb5565-c23e-4605-bb50-b816bace63f5"
client_secret = "Jg3TOoE4Ig4+8WdW/PCDyNJkV5vXrEmLT5ksVmH0fpo="

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************


#########################################################################################
# Authentication - Replace string variables with your relevant values       
#########################################################################################
 
import json, requests, pandas as pd
import datetime
 
try:
    from azure.identity import ClientSecretCredential
except Exception:
     !pip install azure.identity
     from azure.identity import ClientSecretCredential
 
import requests, os, datetime

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Generates the access token for the Service Principal
# api = 'https://analysis.windows.net/powerbi/api/.default'
sharepointApi = "https://graph.microsoft.com/.default"
# sharepointScope = "https://graph.microsoft.com/.default"
sharepointScope = "https://5kbk4y.sharepoint.com/.default"
sharepointApi_MS = "https://login.microsoftonline.com/oauth2/token"
sharepointApi_MS = "https://accounts.accesscontrol.windows.net/3c506d3a-59ac-4090-9034-a1230e5c4fc0/tokens/OAuth/2"
auth = ClientSecretCredential(authority = 'https://login.microsoftonline.com/',
                              tenant_id = tenant,
                              client_id = client,
                              client_secret = client_secret,
                              scope=sharepointApi)

# access_token = auth.get_token(api)
# access_token = auth.get_token(sharepointApi)
access_token = auth.get_token(sharepointScope)
access_token = access_token.token

header = {'Authorization': f'Bearer {access_token}'}

print('\nSuccessfully authenticated.')

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

request1 = "https://5kbk4y.sharepoint.com/sites/MarketMovementShared/_api/web/GetFolderByServerRelativeUrl('/Logistics')/Files"
request2 = "https://5kbk4y.sharepoint.com/sites/MarketMovementShared/_api/web/lists"
response=requests.get(request2, headers=header)
# response=requests.get("https://5kbk4y.sharepoint.com/sites/MarketMovementShared/_api/files", headers=header)
# response=requests.get("https://graph.microsoft.com/v1.0/sites?search=*", headers=header)
response.status_code, response.content.decode()

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def get_response(base_url, relative_path):
    response=requests.get(base_url + relative_path, headers=header)
    return response

def response_to_df(response):
    contentRDD = spark.sparkContext.parallelize([response.content.decode()])
    dfContent = spark.read.json(contentRDD)
    return dfContent

def createTable(dfResponse, tableName):
    ## write the spark dataframe out to a delta table
    if spark.catalog.tableExists(tableName):
            #get existing table
            targetTable = DeltaTable.forName(spark,tableName)
            #merge into table
            (targetTable.alias("t")
                .merge(dfResponse.alias("s"), "s.Id = t.Id")
                .whenMatchedUpdateAll()
                .whenNotMatchedInsertAll()
                .execute()
            )
    else:
        # create workspace table
        dfResponse.write.mode('overwrite').format("delta").saveAsTable(tableName)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Generates the access token for the Service Principal
api = 'https://analysis.windows.net/powerbi/api/.default'
auth = ClientSecretCredential(authority = 'https://login.microsoftonline.com/',
                              tenant_id = tenant,
                              client_id = client,
                              client_secret = client_secret)
access_token = auth.get_token(api)
access_token = access_token.token

print('\nSuccessfully authenticated.')  

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

mssparkutils.notebook.exit(access_token)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
