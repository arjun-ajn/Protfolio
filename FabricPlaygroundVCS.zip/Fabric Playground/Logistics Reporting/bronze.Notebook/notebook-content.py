# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "7135cf11-06a9-4682-81dd-5bbe9a4018a6",
# META       "default_lakehouse_name": "Logistics",
# META       "default_lakehouse_workspace_id": "bc05e361-9f49-4f28-ae66-87d8e1968bd9",
# META       "known_lakehouses": [
# META         {
# META           "id": "7135cf11-06a9-4682-81dd-5bbe9a4018a6"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

pip install xlrd

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

import pandas as pd
from pyspark.sql.functions import col
from pyspark.sql.types import StringType
import pyspark.pandas as ps

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Set up the file path and sheet name
excel_file_path = "/lakehouse/default/Files/bronze/Logistics/BI input SeaFreight Market Movement.xlsx"
excel_sheet_name = "Sea Freight Price"

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

from pyspark.sql.functions import *
from pyspark.sql import functions as F

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

df=ps.read_excel(excel_file_path, header=None, sheet_name=excel_sheet_name)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Not supported

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

df = spark.read.format("com.crealytics.spark.excel").option("header","true").load(excel_file_path)
df=df.select([F.col(col).alias(col.replace(' ', '_')) for col in df.columns])

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

from collections import defaultdict
types = defaultdict(str)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Set up the options and read the file
options = dict(header=0, keep_default_na=False, engine="openpyxl")
df_pandas = pd.read_excel(excel_file_path, sheet_name=excel_sheet_name, dtype=types, **options)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

val someSchema = List(
  StructField("number", IntegerType, true),
  StructField("word", StringType, true)
)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

df_pandas.columns

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

df_spark = spark.createDataFrame(df_pandas)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Convert the pandas dataframe to a PySpark DataFrame
df_spark = ps.DataFrame(df_pandas).to_spark()

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

!pip install winutils

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Define the path to your Excel file
excel_file_path = "Files/bronze/Logistics/BI input SeaFreight Market Movement.xlsx"

df = spark.read \
.format("com.crealytics.spark.excel") \
.option("header", "true") \
.option("inferSchema", "true") \
.load(excel_file_path)

# Show the DataFrame
df.show()


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# # BELOW IS REAL CODE

# CELL ********************

# Set up the file path and sheet name
excel_file_path = "abfss://bc05e361-9f49-4f28-ae66-87d8e1968bd9@onelake.dfs.fabric.microsoft.com/7135cf11-06a9-4682-81dd-5bbe9a4018a6/Files/bronze/Logistics/BI input SeaFreight Market Movement.xlsx"
excel_sheet_name = "Sea Freight Price"

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

import pandas as pd
from pyspark.sql import *
from pyspark.sql.functions import *
from pyspark.sql.types import *

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

df_pandas=pd.read_excel(excel_file_path, sheet_name=excel_sheet_name, header=0, dtype=str)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

df_pandas.head()

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

df_pandas.columns

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

spDf = spark.createDataFrame(df_pandas)
spDf.dtypes

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Function to check if a column contains multiple data types
def check_column_data_types(df):
    mixed_type_columns = {}
    
    for column in df.columns:
        # Convert each value to Python type and get unique types
        # print("Processing column: ", column)
        unique_types = df[column].apply(lambda x: type(eval(x)) if pd.notnull(x) and isinstance(x, str) else type(x)).unique()
        
        if len(unique_types) > 1:
            mixed_type_columns[column] = unique_types
    
    return mixed_type_columns

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Identify columns with mixed data types
mixed_type_columns = check_column_data_types(df_pandas)


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def check_mixed_types(df):
    mixed_columns = {}
    return df.columns

    for column in df.columns:
        # Check if column contains numeric and non-numeric values
        numeric_values = df.filter(col(column).cast(DoubleType()).isNotNull()).count()
        non_numeric_values = df.filter(col(column).cast(DoubleType()).isNull() & col(column).isNotNull()).count()

        if numeric_values > 0 and non_numeric_values > 0:
            mixed_columns[column] = "Contains both numeric and non-numeric values"

    return mixed_columns

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Identify columns with mixed data types
mixed_columns = check_mixed_types(spDf)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Print out columns that have mixed data types
if mixed_columns:
    for column, issue in mixed_columns.items():
        print(f"Column '{column}' has mixed types: {issue}")
else:
    print("No columns with mixed data types were found.")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

spDf.select("Container Size").distinct().show(5)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Print out the columns that have mixed data types
if mixed_type_columns:
    for column, types in mixed_type_columns.items():
        print(f"Column '{column}' has mixed types: {types}")
else:
    print("No columns with mixed data types were found.")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# remove white space in column name
# df=df.select([F.col(col).alias(col.replace(' ', '_')) for col in df.columns])

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# ### BACKUP CODES

# CELL ********************

# TEST CELL - DATEIME DATA TYPE VALIDATOR
from dateutil.parser import parse

def is_date(string, fuzzy=False):
    """
    Return whether the string can be interpreted as a date.

    :param string: str, string to check for date
    :param fuzzy: bool, ignore unknown tokens in string if True
    """
    try: 
        parse(string, fuzzy=fuzzy)
        return True

    except ValueError:
        return False

is_date("1234")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Print out columns that have mixed data types and the types present
# THIS CODE DOES NOT PROVIDE ROW NUMBERS
if mixed_columns_details:
    for column, types in mixed_columns_details.items():
        print(f"Column '{column}' has mixed types: {types}")
else:
    print("No columns with mixed data types were found.")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# NOT REQUIRED ANYMORE
if mixed_columns_with_row_number:
    for column, details in mixed_columns_with_row_number.items():
        print(f"Column '{column}' has mixed types: {details['types']}")
        print(f"  Rows with numeric values: {details['numeric_row_numbers']}")
        print(f"  Rows with non-numeric values: {details['non_numeric_row_numbers']}")
else:
    print("No columns with mixed data types were found.")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# ROW NUMBER with TYPE ERROR
'''
The aim is to find if there are string values in cells which are supposed to have numeric values only
''' 

# Add an index column to track row numbers
w = Window().orderBy(lit('A'))
spDf = spDf.withColumn("row_number", row_number().over(w))

# Function to check for mixed data types and collect row numbers
def check_mixed_types_with_date(df):
    mixed_columns = {}

    for column in df.columns:
        if column == "row_number":
            continue
        
        # Get distinct values to limit the number of checks
        sample_values = df.select(column, "row_number").distinct().collect()
        
        # Track types in this column
        column_types = set()
        row_numbers = {"numeric": [], "string": []}

        for row in sample_values:
            value = row[column]
            row_num = row["row_number"]

            if value is not None:
                try:
                    # Test if it's a numeric (float/int)
                    float(value)
                    column_types.add('numeric')
                    # row_numbers["numeric"].append(row_num)
                except ValueError as error:
                    try:
                        column_types.add('string')
                        row_numbers["string"].append(row_num)
                    except ValueError as error:
                        pass
                    '''
                    # REQUIRED IF DATE TYPE IS TO BE CHECKED
                    # BUT WONT BE REQUIRED AS THIS IS NOT USEFUL/MEANINGFUL CONSIDERING THE REQUIREMENT
                    try:
                        # Test if it's a date
                        # REF: https://www.geeksforgeeks.org/python-datetime-strptime-function/
                        # datetime.datetime.strptime(value, "%Y-%m-%d")
                        # datetime.datetime.strptime(value, "%b-%y")
                        parse(value, fuzzy=False)
                        column_types.add('date')
                        row_numbers["date"].append(row_num)
                    except ValueError:
                        # If not numeric or date, it's treated as a string
                        # print('A ValueError is raised because :', error)
                        
                        try:
                            column_types.add('string')
                            row_numbers["string"].append(row_num)
                        except ValueError as error:
                            print(error)
                            '''

        # If more than one type found, mark the column as mixed
        if len(column_types) > 1:
            mixed_columns[column] = {
                "types": list(column_types),
                "row_numbers": row_numbers
            }
    return mixed_columns

# Identify columns with mixed data types and their row numbers
mixed_columns_details = check_mixed_types_with_date(spDf)

# Print out columns that have mixed data types, the types present, and the row numbers
if mixed_columns_details:
    for column, details in mixed_columns_details.items():
        print(f"Column '{column}' has mixed types: {details['types']}")
        for type_name, rows in details["row_numbers"].items():
            if rows:
                print(f"  Rows with {type_name} values: {rows}")
else:
    print("No columns with mixed data types were found.")

# RESULT
# This cell shows the row number and it's invalid data type

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
