# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "7135cf11-06a9-4682-81dd-5bbe9a4018a6",
# META       "default_lakehouse_name": "Logistics",
# META       "default_lakehouse_workspace_id": "bc05e361-9f49-4f28-ae66-87d8e1968bd9"
# META     }
# META   }
# META }

# MARKDOWN ********************

# # Data Validation & Analytics
# #### This notebook focus on data quality issues with source data. The source data is specifically BAs who would require less effort than full fledged data teams to handle the data.

# CELL ********************

import pandas as pd
import pyspark.sql.functions as F
from pyspark.sql import *
from pyspark.sql.functions import *
from pyspark.sql.types import *
import datetime

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Set up the file path and sheet name
excel_file_path = "abfss://bc05e361-9f49-4f28-ae66-87d8e1968bd9@onelake.dfs.fabric.microsoft.com/7135cf11-06a9-4682-81dd-5bbe9a4018a6/Files/bronze/Logistics/BI input SeaFreight Market Movement.xlsx"
excel_sheet_name = "Sea Freight Price"

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Create pandas DF
df_pandas=pd.read_excel(
    excel_file_path
    , sheet_name=excel_sheet_name
    , header=0
    , dtype=str
    )
df_pandas.head(10)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark",
# META   "frozen": false,
# META   "editable": true
# META }

# CELL ********************

df_pandas.columns

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

df_pandas['masterKey']=df_pandas[["key", "Base Month"]].apply("".join,axis=1)

# df_pandas[["REGION","Loading Country","Loading Port","Destination Port","Destination Country","Container Type","Container Size","key","Base Month","Pre Haul","THC", "masterKey"]]
cols_seaFreightPrice = ["REGION","Loading Country","Loading Port","Destination Port","Destination Country","Container Type","Container Size","Base Month","Pre Haul","THC", "key"]

dfpd_SeaFreightPrice = df_pandas[["masterKey"] + cols_seaFreightPrice]
dfpd_SeaFreightPriceData = df_pandas.drop(cols_seaFreightPrice, axis=1)

cols_seaFreightPriceData = dfpd_SeaFreightPriceData.columns

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

dfpd_SeaFreightPriceData.columns[0:-1]

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# If required, to replace white spaces in column names with "_"

# Method 1: replace white spaces in all column names with "_"
# df_SeaFreightPriceData=df_SeaFreightPriceData.select([F.col(col).alias(col.replace(' ', '_')) for col in df_SeaFreightPriceData.columns])

# Method 2: Column headers: lower case + remove spaces and the following characters: ,;{}()=  
'''
newColumns = []
problematic_chars = ',;{}()='
for column in df.columns:
    column = column.lower()
    column = column.replace(' ', '_')
    for c in problematic_chars:
        column = column.replace(c, '')
    newColumns.append(column)
df = df.toDF(*newColumns)
'''

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark",
# META   "frozen": true,
# META   "editable": false
# META }

# CELL ********************

# Unpivot price data for each masterkey
df_test = spark.createDataFrame(pd.melt(dfpd_SeaFreightPriceData
    , id_vars='masterKey'
    , value_vars = dfpd_SeaFreightPriceData.columns[0:-1]
    , var_name='PriceDate'
    , value_name='PriceValue'
    )
)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

display(df_test.head(10))

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

#Define Schema
schema_SeaFreighPrice = StructType([
    StructField("REGION", StringType(), True),
    StructField("Loading Country", StringType(), True),
    StructField("Loading Port", StringType(), True),
    StructField("Destination Port", StringType(), True),
    StructField("Destination Country", StringType(), True),
    StructField("Container Type", StringType(), True),
    StructField("Container Size", IntegerType(), True),
    StructField("Base Month", DateType(), True),
    StructField("Pre Haul", IntegerType(), True),
    StructField("THC", IntegerType(), True),
    StructField("Key", StringType(), True),
    StructField("MasterKey", StringType(), True)
])

schema_SeaFreighPriceData = StructType([
    StructField("Date", DateType(), True),
    StructField("Price", IntegerType(), True),
    StructField("Price Trend Period", StringType(), True)
])

schema_SeaFreighPriceData = StructType([
    StructField("key", StringType(), True),
    StructField("PriceDate", DateType(), True),
    StructField("Price Value", StringType(), True)
])

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Create spark dataframe
df_SeaFreightPrice = spark.createDataFrame(dfpd_SeaFreightPrice)
df_SeaFreightPriceData = spark.createDataFrame(dfpd_SeaFreightPriceData, schema_SeaFreighPriceData)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark",
# META   "frozen": false,
# META   "editable": true
# META }

# CELL ********************

display(df_SeaFreightPriceData.head(10))

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Get current year
current_year = F.year(F.current_date())

# Extract year and month from 'date'
year_column = F.year("date")
month_column = F.month("date")

df_SeaFreightPriceData = df_SeaFreightPriceData.withColumn(
    "Price Trend Period",
    F.when(
        year_column == current_year,
        F.concat(year_column.cast("string"), F.lit("-"), F.format_string("%02d", month_column))
    ).otherwise(year_column.cast("string"))
)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Create a table in your metastore (e.g., Hive metastore)
# First format column names to remove whitespace
df_SeaFreightPrice=df_SeaFreightPrice.select([F.col(col).alias(col.replace(' ', '_')) for col in df_SeaFreightPrice.columns])
df_SeaFreightPriceData=df_SeaFreightPriceData.select([F.col(col).alias(col.replace(' ', '_')) for col in df_SeaFreightPriceData.columns])

df_SeaFreightPrice.write.format("delta").mode("overwrite").saveAsTable("Logistics.silver_SeaFreight_Price")
df_SeaFreightPriceData.write.format("delta").mode("overwrite").saveAsTable("Logistics.silver_SeaFreight_Price_Data")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Define the schema
'''
# Can be used for future
# https://halismanaz.medium.com/dynamic-json-parsing-in-pyspark-a-guide-to-flexible-schema-handling-ce31dc475fe0#:~:text=PySpark%20can%20parse%20JSON%20strings,to%20that%20%60struct%60%20structure.
[
  {
    "name": "id",
    "type": "integer",
    "nullable": false
  },
  {
    "name": "name",
    "type": "string",
    "nullable": true
  },
  {
    "name": "age",
    "type": "integer",
    "nullable": true
  }
]

# Read the JSON file and parse its contents as a list of dictionaries
with open("schema.json") as f:
    schema_list = json.load(f)

# Create a StructType object from the parsed JSON
fields = []
for field in schema_list:
    name = field["name"]
    data_type = field["type"]
    nullable = field["nullable"]
    if data_type == "string":
        fields.append(StructField(name, StringType(), nullable))
    elif data_type == "integer":
        fields.append(StructField(name, IntegerType(), nullable))
    elif data_type == "boolean":
        fields.append(StructField(name, BooleanType(), nullable))

struct = StructType(fields)
'''

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
