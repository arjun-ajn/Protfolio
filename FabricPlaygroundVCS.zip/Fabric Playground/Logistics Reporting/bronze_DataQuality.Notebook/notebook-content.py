# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "7135cf11-06a9-4682-81dd-5bbe9a4018a6",
# META       "default_lakehouse_name": "Logistics",
# META       "default_lakehouse_workspace_id": "bc05e361-9f49-4f28-ae66-87d8e1968bd9"
# META     }
# META   }
# META }

# MARKDOWN ********************

# # Data Quality Assessment(for BAs)
# #### This notebook focus on data quality issues with source data. The source data is specifically BAs who would require less effort than full fledged data teams to handle the data.

# CELL ********************

import pandas as pd
from pyspark.sql import *
from pyspark.sql.functions import *
from pyspark.sql.types import *
import datetime
from dateutil.parser import parse

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Set up the file path and sheet name
excel_file_path = "abfss://bc05e361-9f49-4f28-ae66-87d8e1968bd9@onelake.dfs.fabric.microsoft.com/7135cf11-06a9-4682-81dd-5bbe9a4018a6/Files/bronze/Logistics/BI input SeaFreight Market Movement.xlsx"
excel_sheet_name = "Sea Freight Price"

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Create pandas DF
df_pandas=pd.read_excel(excel_file_path, sheet_name=excel_sheet_name, header=0, dtype=str)
df_pandas.head()

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark",
# META   "frozen": false,
# META   "editable": false
# META }

# CELL ********************

# Create spark dataframe
spDf = spark.createDataFrame(df_pandas)

# spDf.dtypes  # check dtypes of all columns

# Known data type mismatch
# spDf.select("Container Size").distinct().show(5)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark",
# META   "frozen": false,
# META   "editable": true
# META }

# CELL ********************

# Row counts - As in source data
print(f"There are {df_pandas.shape[0]} rows and {df_pandas.shape[1]} columns in source data.")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Validate data integrity
print(f"There are {spDf.count()} rows and {len(spDf.columns)} columns in the spark dataframe.") 

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Validate data integrity

validRows = df_pandas.shape[0] == spDf.count()  # Check row counts
validColumns = df_pandas.shape[1]==len(spDf.columns)  # Check column counts

if not(validRows):
    print(f"Rows mismatch PANDAS: {df_pandas.shape[0]} and SPARK: {spDf.count()}")
elif not(validColumns):
    print(f"Columns mismatch PANDAS: {df_pandas.shape[1]} and SPARK: {len(spDf.columns)}")
else:
    print("Data integrity is intact - Number of rows and columns match")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Not optimized using distinct
# Define function to identify mixed data types
def check_mixed_types(df):
    mixed_columns = {}

    for column in df.columns:
        # Check if column contains numeric and non-numeric values
        numeric_values = df.filter(col(column).cast(DoubleType()).isNotNull()).count()
        non_numeric_values = df.filter(col(column).cast(DoubleType()).isNull() & col(column).isNotNull()).count()

        if numeric_values > 0 and non_numeric_values > 0:
            mixed_columns[column] = "Contains both numeric and non-numeric values"

    return mixed_columns

# Identify columns with mixed data types
mixed_columns = check_mixed_types(spDf)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark",
# META   "frozen": true,
# META   "editable": false
# META }

# CELL ********************

# TEST 1 - Mixed Data Types - Identifies text and numeric issues
# Print out columns that have mixed data types
if mixed_columns:
    for column, issue in mixed_columns.items():
        print(f"Column '{column}' has mixed types: {issue}")
else:
    print("No columns with mixed data types were found.")

# RESULT
# This code sohws the types of data only. This does not show the row number. This will be done in TEST 2

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark",
# META   "frozen": true,
# META   "editable": false
# META }

# CELL ********************

# ROW NUMBER with TYPE ERROR
'''
The aim is to find if there are string values in cells which are supposed to have numeric values only
''' 

# Add an index column to track row numbers
w = Window().orderBy(lit('A'))
spDf = spDf.withColumn("row_number", row_number().over(w))

# Function to check for mixed data types and collect row numbers
def check_mixed_types_with_date(df):
    mixed_columns = {}

    for column in df.columns:
        if column == "row_number":
            continue
        
        # Get distinct values to limit the number of checks
        sample_values = df.select(column, "row_number").distinct().collect()
        
        # Track types in this column
        column_types = set()
        row_numbers = {"numeric": [], "string": []}

        for row in sample_values:
            value = row[column]
            row_num = row["row_number"]

            if value is not None:
                try:
                    # Test if it's a numeric (float/int)
                    float(value)
                    column_types.add('numeric')
                    # row_numbers["numeric"].append(row_num)
                except ValueError as error:
                    try:
                        column_types.add('string')
                        row_numbers["string"].append(row_num)
                    except ValueError as error:
                        print(f"Ohter error: {error}")

        # If more than one type found, mark the column as mixed
        if len(column_types) > 1:
            mixed_columns[column] = {
                "types": list(column_types),
                "row_numbers": row_numbers
            }
    return mixed_columns

# Identify columns with mixed data types and their row numbers
mixed_columns_details = check_mixed_types_with_date(spDf)

# Print out columns that have mixed data types, the types present, and the row numbers
if mixed_columns_details:
    for column, details in mixed_columns_details.items():
        print(f"Column '{column}' has mixed types: {details['types']}")
        for type_name, rows in details["row_numbers"].items():
            if rows:
                print(f"  Rows with {type_name} values: {rows}")
else:
    print("No columns with mixed data types were found.")

# RESULT
# This cell shows the row number and it's invalid data type

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# NOTE: KNOWN ISSUE - ROW NUMBERS DO NOT MATCH WITH THE EXCEL SHEET
# display(spDf)
display(spDf.collect()[8929])

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# remove white space in column name
# df=df.select([F.col(col).alias(col.replace(' ', '_')) for col in df.columns])

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
