# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "7135cf11-06a9-4682-81dd-5bbe9a4018a6",
# META       "default_lakehouse_name": "Logistics",
# META       "default_lakehouse_workspace_id": "bc05e361-9f49-4f28-ae66-87d8e1968bd9"
# META     }
# META   }
# META }

# MARKDOWN ********************

# # Silver Layer - ETL

# CELL ********************

import pandas as pd
import pyspark.sql.functions as F
from pyspark.sql import *
from pyspark.sql.functions import *
from pyspark.sql.types import *
import datetime

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

df_SeaFreightPrice = spark.sql("SELECT * FROM Logistics.bronze_SeaFreightPrice LIMIT 1000")
display(df_SeaFreightPrice.head(10))

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# DEFINE FUNCTIONS
def trim_all_string_columns(df: DataFrame) -> DataFrame:
    return df\
        .select(
            *[trim(col(c[0])).alias(c[0]) if c[1] == 'string' else col(c[0]) for c in df.dtypes]
        )

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Trim white spaces to avoind unexpected issues
df_SeaFreightPrice = df_SeaFreightPrice\
  .transform(trim_all_string_columns)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# cols_seaFreightPrice = ["REGION","Loading Country","Loading Port","Destination Port","Destination Country","Container Type","Container Size","Base Month","Pre Haul","THC", "key"]
cols_seaFreightPrice = df_SeaFreightPrice.columns
# cols_seaFreightPrice
cols_masterKey = ['REGION', 'Loading_Country', 'Loading_Port', 'Destination_Port', 'Destination_Country', 'Container_Type', 'Container_Size', 'Month']

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Create master key column
df_SeaFreightPrice = df_SeaFreightPrice.withColumn(
    "masterKey",
    concat(col("REGION")
    , col("Loading_Country")
    , col("Loading_Country")
    , col("Loading_Port")
    , col("Destination_Port")
    , col("Destination_Country")
    , col("Container_Type")
    , col("Container_Size")
    , col("Month"))
)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

display(df_SeaFreightPrice.head(10))

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Normalization - Remove columns
# df_SeaFreightPriceData = df_SeaFreightPrice.drop(cols_seaFreightPrice)
# cols_seaFreightPriceData = df_SeaFreightPriceData.columns

df_SeaFreightPriceData = df_SeaFreightPrice.select(
    [c for c in df_SeaFreightPrice.columns if c not in cols_masterKey]
)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

display(df_SeaFreightPriceData.head(10))

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Unpivot price data for each masterkey
df_SeaFreightPriceData = pd.melt(df_SeaFreightPriceData
    , id_vars=cols_seaFreightPriceData[-1]
    , value_vars = df_SeaFreightPriceData.columns[0:-1]
    , var_name='Date'
    , value_name='Price'
    )

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark",
# META   "frozen": true,
# META   "editable": false
# META }

# CELL ********************

#Define Schema
schema_SeaFreighPrice = StructType([
    StructField("REGION", StringType(), True),
    StructField("Loading Country", StringType(), True),
    StructField("Loading Port", StringType(), True),
    StructField("Destination Port", StringType(), True),
    StructField("Destination Country", StringType(), True),
    StructField("Container Type", StringType(), True),
    StructField("Container Size", IntegerType(), True),
    StructField("Base Month", DateType(), True),
    StructField("Pre Haul", IntegerType(), True),
    StructField("THC", IntegerType(), True),
    StructField("Key", StringType(), True),
    StructField("MasterKey", StringType(), True)
])

schema_SeaFreighPriceData = StructType([
    StructField("Date", DateType(), True),
    StructField("Price", IntegerType(), True),
    StructField("Price Trend Period", StringType(), True)
])

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
